SELECT
"id" AS "id",
COUNT("log_feature") AS "log_feature_count",
string_agg("log_feature", ', ') AS "log_features",
COUNT("volume") AS "volume_count",
string_agg("volume", ', ') AS "volumes"         
  FROM "TELSTRANETWORKDISRUPTIONS_log_feature_copy"
GROUP BY "id"
