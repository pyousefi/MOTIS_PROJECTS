SELECT
"id" AS "id",
COUNT ("event_type") AS "event_type_count", 
string_agg("event_type", ', ') AS "event_types"
FROM "TELSTRANETWORKDISRUPTIONS_event_type_copy"
GROUP BY "id"


