SELECT 
    "id" AS "id",
    COUNT("event_type") AS "event_type_count",
    string_agg("event_type", ', ') AS "event_types"
  FROM "TELSTRA_NETWORK_DISRUPTIONS_event_type_copy"
  GROUP BY "id"