SELECT *,
RANK() OVER(Partition by "location" Order by "row_number") as rank
  FROM "TELSTRA_NETWORK_DISRUPTIONS_all_info"
order by row_number