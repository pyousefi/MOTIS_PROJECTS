SELECT row_number() over(), *
  FROM "TELSTRA_NETWORK_DISRUPTIONS_severity_type_joined"