SELECT 
    "id" AS "id",
    COUNT("resource_type") AS "resource_type_count",
    string_agg("resource_type", ', ') AS "resource_types"
FROM "TELSTRA_NETWORK_DISRUPTIONS_resource_type_copy"
  GROUP BY "id"