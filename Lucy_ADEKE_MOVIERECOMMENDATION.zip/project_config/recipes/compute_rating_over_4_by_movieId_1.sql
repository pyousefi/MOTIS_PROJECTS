SELECT * FROM
( select
sum("mul_Action_genre_rating")/ count ("mul_Action_genre_rating") AS "Action"
  FROM 
      "MOVIERECOMMENDATION_movies_preparedd_ratings_joined_genre_rating" 
      where "mul_Action_genre_rating">0 
 
 )


