SELECT 
sum("mul_Adventure_genre_rating")/ count ("mul_Adventure_genre_rating") AS "Average_Rating"
  FROM 
      "MOVIERECOMMENDATION_rating_over_4" 
      where "mul_Adventure_genre_rating">0  

