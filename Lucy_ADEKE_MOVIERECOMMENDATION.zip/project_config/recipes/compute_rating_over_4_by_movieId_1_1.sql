SELECT 
sum("mul_Documentary_genre_rating")/ count ("mul_Documentary_genre_rating") AS "Average_rating"
  FROM 
      "MOVIERECOMMENDATION_rating_over_4" 
      where "mul_Documentary_genre_rating">0  


