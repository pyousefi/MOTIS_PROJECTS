SELECT 
sum("mul_Comedy_genre_rating")/ count ("mul_Comedy_genre_rating") AS "Average_Rating"
  FROM 
      "MOVIERECOMMENDATION_movies_preparedd_ratings_joined_genre_rating" 
      where "mul_Comedy_genre_rating">0



